<?php
// +----------------------------------------------------------------------
// | OneThink [ WE CAN DO IT JUST THINK IT ]
// +----------------------------------------------------------------------
// | Copyright (c) 2015 http://www.MomcHomeS.com All rights reserved.
// +----------------------------------------------------------------------
// | Author: zhuyajie <xcoolcc@gmail.com>
// +----------------------------------------------------------------------

namespace Admin\Model;
use Think\Model;
/**
 * 权限规则模型
 * @author 朱亚杰 <zhuyajie@MomcHome.com>
 */
class AuthRuleModel extends Model{
    
    const RULE_URL = 1;
    const RULE_MAIN = 2;

}
